const User = require("../models/User");
const Post = require("../models/Post");

// GET USER PROFILE
const getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select("-password")
      .populate("savedPosts");

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    res.status(200).json({
      success: true,
      user,
    });
  } catch (error) {
    console.error("Get profile error:", error);
    res.status(500).json({ success: false, message: "Failed to fetch profile" });
  }
};

// UPDATE USER PROFILE
const updateUserProfile = async (req, res) => {
  try {
    const { name, phone, bio, profileImage } = req.body;

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    if (name) user.name = name.trim();
    if (phone !== undefined) user.phone = phone.trim();
    if (bio !== undefined) user.bio = bio.trim();
    if (profileImage !== undefined) user.profileImage = profileImage;

    await user.save();

    res.status(200).json({
      success: true,
      message: "Profile updated successfully",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        bio: user.bio,
        profileImage: user.profileImage,
      },
    });
  } catch (error) {
    console.error("Update profile error:", error);
    res.status(500).json({ success: false, message: "Failed to update profile" });
  }
};

// TOGGLE SAVED POST

const mongoose = require("mongoose");

const toggleSavedPost = async (req, res) => {
  try {
    const { postId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(postId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid post ID",
      });
    }

    const [user, post] = await Promise.all([
      User.findById(req.user._id),
      Post.findById(postId),
    ]);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    if (!post) {
      return res.status(404).json({
        success: false,
        message: "Post not found",
      });
    }

    const postIndex = user.savedPosts.findIndex(
      (id) => id.toString() === postId
    );

    let isSaved;

    if (postIndex > -1) {
      user.savedPosts.splice(postIndex, 1);
      isSaved = false;
    } else {
      user.savedPosts.push(post._id);
      isSaved = true;
    }

    await user.save();

    return res.status(200).json({
      success: true,
      isSaved,
      message: isSaved
        ? "Post saved to bookmarks"
        : "Post removed from bookmarks",
      savedPosts: user.savedPosts,
    });
  } catch (error) {
    console.error("Toggle saved post error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to toggle saved post",
    });
  }
};


// GET SAVED POSTS
const getSavedPosts = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate({
      path: "savedPosts",
      populate: { path: "user", select: "name email profileImage" },
    });

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    res.status(200).json({
      success: true,
      count: user.savedPosts.length,
      savedPosts: user.savedPosts,
    });
  } catch (error) {
    console.error("Get saved posts error:", error);
    res.status(500).json({ success: false, message: "Failed to fetch saved posts" });
  }
};

module.exports = {
  getUserProfile,
  updateUserProfile,
  toggleSavedPost,
  getSavedPosts,
};
