const express = require("express");
const router = express.Router();

const {
  createEnquiry,
  getMyEnquiries,
  deleteEnquiry,
} = require("../controllers/enquiryController");

const { protect } = require("../middleware/authMiddleware");

// Optional auth middleware for createEnquiry
const optionalAuth = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    return protect(req, res, next);
  }
  next();
};

router.post("/", optionalAuth, createEnquiry);
router.get("/my", protect, getMyEnquiries);
router.delete("/:id", protect, deleteEnquiry);

module.exports = router;
