const express = require("express");
const router = express.Router();

const {
  getUserProfile,
  updateUserProfile,
  toggleSavedPost,
  getSavedPosts,
} = require("../controllers/userController");

const { protect } = require("../middleware/authMiddleware");

// User Profile routes
router.get("/profile", protect, getUserProfile);
router.put("/profile", protect, updateUserProfile);

// Saved / Bookmarks routes
router.post("/saved/:postId", protect, toggleSavedPost);
router.get("/saved", protect, getSavedPosts);

module.exports = router;
