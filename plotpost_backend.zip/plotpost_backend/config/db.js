const mongoose = require("mongoose");
const dns = require("dns");

// Fix for Node.js DNS resolution issues on Windows (querySrv ECONNREFUSED)
try {
  dns.setServers(["1.1.1.1", "8.8.8.8", "192.168.1.1"]);
} catch (err) {
  // Ignore if custom DNS fallback fails
}

const connectDB = async () => {
  try {
    const connection = await mongoose.connect(process.env.MONGODB_URI);

    console.log(`MongoDB Connected: ${connection.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;