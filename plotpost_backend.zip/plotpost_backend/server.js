require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const dns = require('dns');
const cors = require('cors');

// Fix for Node.js DNS resolution issues on Windows (querySrv ECONNREFUSED)
try {
  dns.setServers(['1.1.1.1', '8.8.8.8', '192.168.1.1']);
} catch (err) {
  // Ignore if custom DNS fallback fails
}

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: "12mb" }));

// Route handlers
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/posts", require("./routes/postRoutes"));
app.use("/api/upload", require("./routes/uploadRoutes"));
app.use("/api/enquiries", require("./routes/enquiryRoutes"));

app.get('/api/health', (req, res) => {
  const isDatabaseConnected = mongoose.connection.readyState === 1;
  res.status(isDatabaseConnected ? 200 : 503).json({
    success: isDatabaseConnected,
    database: isDatabaseConnected ? 'connected' : 'disconnected',
  });
});

// Test route
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: '🚀 PlotPost Backend is running!'
  });
});

// MongoDB connection
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      serverSelectionTimeoutMS: 10000,
    });

    console.log('✅ MongoDB connected successfully');
  } catch (error) {
    console.error('❌ MongoDB connection error:');
    console.error(error.message);
  }
};

// Start server
const PORT = process.env.PORT || 5000;

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server running on port ${PORT}`);
});

// Connect to MongoDB
connectDB();
